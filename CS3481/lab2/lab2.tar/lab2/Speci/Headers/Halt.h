
class Halt: protected Group9
{
   public:
      Halt(Cpu * c, Memory *m);
      void execute();
};

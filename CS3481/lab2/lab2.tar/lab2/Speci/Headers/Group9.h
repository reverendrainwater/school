
class Group9: protected Instruction
{
   public:
      Group9(Cpu * c, Memory * m);  
};   


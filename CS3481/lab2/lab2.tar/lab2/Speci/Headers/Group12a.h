
class Group12a: protected Instruction
{
   public:
      Group12a(Cpu * c, Memory * m);  
};   



class Trap: protected Group12a
{
   public:
      Trap(Cpu * c, Memory *m);
      void execute();
};

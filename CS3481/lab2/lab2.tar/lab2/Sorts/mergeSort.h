
void mergeSort(int * list, int count);



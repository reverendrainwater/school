
void bubblesort(int * list, int i);



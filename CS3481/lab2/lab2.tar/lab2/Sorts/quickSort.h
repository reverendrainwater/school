void quickSort(int * list, int count);
